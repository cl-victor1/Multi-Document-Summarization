Maryland oysters, the shining jewels of Chesapeake Bay, are becoming an endangered species.
The annual haul in 2003 was about 23,000 bushels compared to 80,000 in 1993 and 2 million plus in the 1980's.
Maryland and Virginia have taken steps to protect native oysters, but both are considering introducing the Chinese oyster as a replacement.
As optimism about the Chinese oyster has grown in the administration of Gov. Robert Ehrlich (R-MD), pessimism has spread among scientists.
Maryland has successfully spawned and raised native oysters in managed reserves under scientific supervision but the process is slow and limited in scope.
