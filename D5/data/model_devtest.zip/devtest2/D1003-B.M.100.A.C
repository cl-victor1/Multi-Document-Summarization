A regional telecom network which now covers China's Wolong Grant Panda Nature Reserve "will not only help increase the number of giant pandas but will also help us manage the living environment of giant pandas" the Reserve's director declared on April 3, 2005.
On May 7 it was announced that China plans to build a new giant panda museum to help save the endangered animal and its habitat.
On May 10 the Southwest Sichuan Province government announced that it had closed 78 mines and polluting companies in the giant panda's habitat.
