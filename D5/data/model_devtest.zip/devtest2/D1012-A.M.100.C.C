Flight 522 of the Cypriot airline Helios bound for Athens from Larnaka Cyprus crashed at 12:05 p.m.
August 14, 2005 near the coastal town of Grammatikos killing all 121 aboard including 48 Greek Cypriot children and youths.
Reports from Greek air force pilots who intercepted the doomed airline suggest that a catastrophic loss of cabin pressure could have caused the crash.
Cyprus Transport Minister Haris Thrasou said the plane had problems with decompression in the past.
The plane's black box has been recovered and the investigation of the cause of the crash is underway.
