Head injuries such as concussions can be prevented or minimized by wearing helmets or other headgear.
In some jurisdictions motorcyclists are required to wear helmets.
In sports cyclists and football players can reduce their risk by wearing helmets; hockey players by wearing masks; basketball and tennis players by wearing eye guards; and baseball players by using batting helmets.
In New York state law requires bicycle riders, in-line skaters and skateboarders under 14 to wear helmets.
A San Diego-based firm has produced a headgear for soccer where the incidence of concussions is high.
