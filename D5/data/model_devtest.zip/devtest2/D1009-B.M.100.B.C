On March 23, 1999 the grand jury investigating the JonBenet Ramsey slaying received funding for three months more of operation.
On April 8 the grand jury was granted an extension until Oct. 20.
Although prosecutors have only identified the parents as under suspicion, unidentified DNA material in JonBenet's underwear and a shoe print found near the body suggest the possibility of an intruder.
Nearly a year after the grand jury began looking at the case, there is no indication it is any closer to a resolution.
