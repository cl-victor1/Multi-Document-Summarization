On March 17, 2005 thirty people were killed and more than 70 wounded in fierce gun battles between Pakistani soldiers and Bugti tribesmen in the southwestern province of Baluchistan.
The exchange of rockets and mortar shells continued all day after the rebels ambushed a Pakistani convoy in the tribal stronghold of Dera Bugti.
A senior official there reported about 5000 armed tribesmen positioned in mountains outside the town where both sides are evacuating residents.
Baluchistan has for more than a year experienced attacks by tribesmen demanding more revenue in compensation for natural resources extracted from their territory.
