The jury in the Robert Blake trial began deliberation on March 4, 2005.
On March 9 jurors reviewed testimony by three people who saw Blake the night of the murder.
It was the only time that jurors asked the court for information from the trial.
On March 15 the 12-month trial ended when the jury, after nine days of deliberation, found Blake not guilty of murder and in one case of solicitation.
The jury deadlocked 11-1 on the other solicitation charge which the judge later dismissed.
Jury foreman Thomas Nicholson said that "the circumstantial evidence was flimsy."
