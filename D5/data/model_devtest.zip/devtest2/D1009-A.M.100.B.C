Six-year-old JonBenet Ramsey was found beaten and strangled on Dec. 26, 1996 in her home in Boulder, Colorado.
No one has been charged in the case although both Alex Hunter, Boulder's district attorney, and Mark Beckner, Boulder's police chief, have said that JonBenet's parents, John and Patsy Ramsey, fall under "the umbrella of suspicion".
The Ramseys' attorney, Hal Haddon, said that they don't trust the Boulder police.
On Sept. 15, 1998 District Attorney Hunter took the case before a grand jury.
