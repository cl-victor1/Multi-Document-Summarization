Mount St. Helens in southwest Washington state erupted violently on May 18, 1980 killing 57people, destroying 200 homes and coating much of the northwest with 520 million tons of ash.
Seismic activity beginning on Sept. 23, 2004 released more energy than at any time since 1980 and on October 1 the volcano burped a tall column of steam and ash.
Seismic activity ceased briefly but resumed.
On Oct. 2 scientists warned of a more serious eruption threatening life and property.
Officials evacuated an observatory 5 miles from the crater and moved tourists to a lookout point several miles below.
