In 1999 1,350 individuals were charged under the Identity Theft and Assumption Deterrence Act of which 644 were sentenced, and 407 entered guilty pleas.
An IT hotline established by the Federal Trade Commission in 1999 received about 400 calls per week.
An insurance company is now offering a policy covering some of the expenses incurred by IT victims.
As IT cases have increased, so have sales of shredders from about 100,000 in 1990 to 9 million in 1998.
The widespread use of Social Security numbers as a national identification calls for corrective legislation.
