The mortality rate of motorcycle crash patients has remained at about 5 percent in recent years with most dying in the first 24 hours from head injuries.
There has been an increase in helmet usage from 30% to 48%.
In 2005 in the U.S. only Washington, D.C. and 20 states mandate motorcycle helmets.
Opponents complain that such laws violate personal freedom.
