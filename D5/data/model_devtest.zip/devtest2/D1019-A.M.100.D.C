On April 23, 2000 six masked assailants armed with rocket launchers and M16 rifles abducted 20 people from a beach on Sipadan Island off the coast of Sabah, the Malaysian side of Borneo Island.
Ten of the captives are foreign tourists and ten Malaysians from the resort area popular with scuba divers.
The gunmen forced their hostages to swim to two fishing boats which sped away toward Philippine waters.
A Philippine Muslim separatist group, Abu Sayyaf, claimed responsibility for the abductions, but neither this claim nor location of the 20 captives has been confirmed.
