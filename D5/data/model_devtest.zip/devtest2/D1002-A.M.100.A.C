A trial date of Jan.3, 2000 has been set for the Anadol Diallo case.
Four New York City police officers are charged with second degree murder of 22-year-old immigrant street vendor from Guinea when on Feb. 4, 1999 they fired 41 shots of which 19 hit the unarmed victim.
The four officers, Kenneth Boss, Jean Carroll, Edward McMellon and Richard Murphy pleaded not guilty maintaining that they thought Diallo was armed.
Bronx District Attorney Robert Johnson charged that the officers intended to take Diallo's life.
