Obesity is a major health problem since people who are overweight have increased tendencies toward cardiovascular and cerebral disease, diabetes and kidney and liver disease.
In China about 70 million are obese.
A survey in 1996 in Shanghai found that 12.6% of adults and 11.35% of children are obese.
The incidence in Britain is 16% of women and 13% of men; in Kuwait, 42% of women and 28% of men.
The main causes of obesity are lack of regular exercise and poor diet.
Kuwait, Egypt, and Lebanon have reported successful use of hypnotism in treating obesity.
