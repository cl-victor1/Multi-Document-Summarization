The U.S. attack gave President Omar el-Bashir an opportunity to rally support at home and to a lesser extent abroad.
In Khartoum crowds demonstrated hatred for America shouting "Down, Down, USA"! and disdain for President Clinton pictured with Monica Lewinsky.
The Arab League condemned the U.S. "serious aggression against a sovereign Arab country" while Iran and Yemen termed the attack as a violation of Sudan's sovereignty and international law.
Egypt called for a world summit on combating terrorism, while Jordan suggested resolution of disputes through dialog.
Turkey and Israel both supported the U.S. action.
