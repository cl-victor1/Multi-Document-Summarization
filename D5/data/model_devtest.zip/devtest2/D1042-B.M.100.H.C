The sentencing phase of England's trial began on May 3, 2005.
On May 4 the judge abruptly tossed out England's guilty plea, declared a mistrial, dismissed the jury, and referred matters back to Lt. Gen. Thomas F. Metz, Ft.
Hood's commander.
The judge said defense testimony that England did not know what she was doing was wrong.
"You can't plead guilty and then say you're not".
Prosecutors, Capt. Chris Graveline and Capt. Chuck Neill, and defense lawyers, Capt. Jonathan Crisp and Rich Hernandez, made no public comment.
Metz can drop charges, refer them to another hearing, or recommend non-judicial punishment.
